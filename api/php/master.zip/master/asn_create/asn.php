<?php

class asn{

    public $po_reference='';
    public $asn_reference='';
    public $expected_date='19000101';
	public $shipper='';
	public $carrier='Unknown';
	public $notes='';
	public $cartons='0';
	public $pallets='0';
	public $autorelease='1';
	public $asn_items;

    public function __construct(){
    }


}
?>